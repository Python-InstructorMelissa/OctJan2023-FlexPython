from app import app

from app.controllers import tasks

if __name__=="__main__":
    app.run(debug=True)    # Run the app in debug mode.